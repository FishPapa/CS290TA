
console.log("Lets make sure JavaScript is working.");

var name = "Yuanjun";

console.log("The unicode characters of your name are:")

for (var i = 0; i < name.length; i++){
	console.log(name.charCodeAt(i));
}

console.log("Copy and paste these values for activity credit.")
